
//<!-- ============================================================================
//
//THIS IS A FICTIONAL CASE STUDY WEBSITE FOR TRAINING PURPOSE ONLY.
//
//THIS IS A HAND CODED CASE STUDY DESIGN FROM SCRATCH
//
//============================================================================ -->
//    
//    
//
//===========================================================================
//    MOBILE DEVICE MENU SCRIPT
//===========================================================================

$("span.navBtn").click(function() {
    $("ul.menu-items").slideToggle();
});